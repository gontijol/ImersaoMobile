main() {
  var lista = const ['Ana', 'Lia', 'Gui'];
  // lista = const ['Banana', 'Maça'];

  lista.add('Rebeca');
  print(lista);
}
