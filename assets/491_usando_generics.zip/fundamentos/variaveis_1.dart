main() {
  int a = 2;
  double b = 3.1314;
  b = 3.1415;

  print(a * b);
  print(1 + 2 * 4);
}
